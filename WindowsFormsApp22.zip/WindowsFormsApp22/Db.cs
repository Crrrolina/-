﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace ToysStore
{
    public class Db
    {
        public const string ConnectionString =
            @"Data Source=dorinmaxxx\SQLEXPRESS;Initial Catalog=demoNeHack;Integrated Security=True;Encrypt=False";

        private SqlConnection Open()
        {
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            return con;
        }

        private bool ColumnExists(string table, string column)
        {
            using (SqlConnection con = Open())
            using (SqlCommand cmd = new SqlCommand("SELECT COL_LENGTH(@table, @column)", con))
            {
                cmd.Parameters.AddWithValue("@table", "dbo." + table);
                cmd.Parameters.AddWithValue("@column", column);

                return cmd.ExecuteScalar() != DBNull.Value;
            }
        }

        // Заказы больше не используют Clients: связь идет через Orders.Person -> Persons.Id.
        private string GetOrderPersonColumn()
        {
            return "Person";
        }

        public CurrentUser Login(string login, string password)
        {
            string sql = @"
                SELECT TOP 1 ua.Id, ua.Login, ua.EmployeeRole,
                    p.LastName + ' ' + p.FirstName + ' ' + p.MiddleName AS FullName
                FROM UserAccounts ua
                JOIN Persons p ON p.Id = ua.Person
                WHERE ua.Login = @login AND ua.Password = @password";

            using (SqlConnection con = Open())
            using (SqlCommand cmd = new SqlCommand(sql, con))
            {
                cmd.Parameters.AddWithValue("@login", login);
                cmd.Parameters.AddWithValue("@password", password);

                using (SqlDataReader r = cmd.ExecuteReader())
                {
                    if (!r.Read()) return null;

                    return new CurrentUser
                    {
                        Id = Convert.ToInt32(r["Id"]),
                        Login = r["Login"].ToString(),
                        FullName = r["FullName"].ToString(),
                        Role = (UserRole)Convert.ToInt32(r["EmployeeRole"])
                    };
                }
            }
        }

        public List<Product> GetProducts()
        {
            List<Product> list = new List<Product>();

            string sql = @"
SELECT p.*, u.Name AS UnitName, s.Name AS SupplierName,
       m.Name AS ManufacturerName, c.Name AS CategoryName
FROM Products p
JOIN Units u ON u.Id = p.Unit
JOIN Suppliers s ON s.Id = p.Supplier
JOIN Manufacturers m ON m.Id = p.Manufacturer
JOIN Categories c ON c.Id = p.ProductCategory
ORDER BY p.ProductName";

            using (SqlConnection con = Open())
            using (SqlCommand cmd = new SqlCommand(sql, con))
            using (SqlDataReader r = cmd.ExecuteReader())
            {
                while (r.Read())
                {
                    Product p = new Product();

                    p.ArticleNumber = r["ArticleNumber"].ToString();
                    p.ProductName = r["ProductName"].ToString();
                    p.Unit = Convert.ToInt32(r["Unit"]);
                    p.Price = r["Price"] == DBNull.Value ? 0 : Convert.ToDouble(r["Price"]);
                    p.Supplier = Convert.ToInt32(r["Supplier"]);
                    p.Manufacturer = Convert.ToInt32(r["Manufacturer"]);
                    p.ProductCategory = Convert.ToInt32(r["ProductCategory"]);
                    p.CurrentDiscount = r["CurrentDiscount"] == DBNull.Value ? 0 : Convert.ToDouble(r["CurrentDiscount"]);
                    p.QuantityInStock = r["QuantityInStock"] == DBNull.Value ? 0 : Convert.ToDouble(r["QuantityInStock"]);
                    p.ProductDescription = r["ProductDescription"].ToString();
                    p.Photo = r["Photo"] == DBNull.Value ? "" : r["Photo"].ToString();

                    p.UnitName = r["UnitName"].ToString();
                    p.SupplierName = r["SupplierName"].ToString();
                    p.ManufacturerName = r["ManufacturerName"].ToString();
                    p.CategoryName = r["CategoryName"].ToString();

                    list.Add(p);
                }
            }

            return list;
        }

        // Таблица выбирается из белого списка, так как имя таблицы нельзя передать SQL-параметром.
        public List<LookupItem> GetLookup(string table)
        {
            if (table != "Units" &&
                table != "Suppliers" &&
                table != "Manufacturers" &&
                table != "Categories" &&
                table != "Persons" &&
                table != "PickupPoints" &&
                table != "OrderStatuses")
            {
                throw new ArgumentException("Запрошен неизвестный справочник: " + table);
            }

            string nameField = "Name";
            string sourceTable = table;

            if (table == "Persons")
            {
                sourceTable = "Persons";
                nameField = "LastName + ' ' + FirstName + ' ' + MiddleName";
            }

            if (table == "PickupPoints")
                nameField = "CAST([Index] AS nvarchar) + ', ' + Address";

            string sql = "SELECT Id, " + nameField + " AS Name FROM " + sourceTable + " ORDER BY Name";

            List<LookupItem> list = new List<LookupItem>();

            using (SqlConnection con = Open())
            using (SqlCommand cmd = new SqlCommand(sql, con))
            using (SqlDataReader r = cmd.ExecuteReader())
            {
                while (r.Read())
                {
                    list.Add(new LookupItem
                    {
                        Id = Convert.ToInt32(r["Id"]),
                        Name = r["Name"].ToString()
                    });
                }
            }

            return list;
        }

        public void AddProduct(Product p)
        {
            string sql = @"
INSERT INTO Products
(ArticleNumber, ProductName, Unit, Price, Supplier, Manufacturer, ProductCategory,
 CurrentDiscount, QuantityInStock, ProductDescription, Photo)
VALUES
(@ArticleNumber, @ProductName, @Unit, @Price, @Supplier, @Manufacturer, @ProductCategory,
 @CurrentDiscount, @QuantityInStock, @ProductDescription, @Photo)";

            SaveProductSql(sql, p);
        }

        public void UpdateProduct(Product p)
        {
            string sql = @"
UPDATE Products SET
ProductName = @ProductName,
Unit = @Unit,
Price = @Price,
Supplier = @Supplier,
Manufacturer = @Manufacturer,
ProductCategory = @ProductCategory,
CurrentDiscount = @CurrentDiscount,
QuantityInStock = @QuantityInStock,
ProductDescription = @ProductDescription,
Photo = @Photo
WHERE ArticleNumber = @ArticleNumber";

            SaveProductSql(sql, p);
        }

        private void SaveProductSql(string sql, Product p)
        {
            using (SqlConnection con = Open())
            using (SqlCommand cmd = new SqlCommand(sql, con))
            {
                cmd.Parameters.AddWithValue("@ArticleNumber", p.ArticleNumber);
                cmd.Parameters.AddWithValue("@ProductName", p.ProductName);
                cmd.Parameters.AddWithValue("@Unit", p.Unit);
                cmd.Parameters.AddWithValue("@Price", p.Price);
                cmd.Parameters.AddWithValue("@Supplier", p.Supplier);
                cmd.Parameters.AddWithValue("@Manufacturer", p.Manufacturer);
                cmd.Parameters.AddWithValue("@ProductCategory", p.ProductCategory);
                cmd.Parameters.AddWithValue("@CurrentDiscount", p.CurrentDiscount);
                cmd.Parameters.AddWithValue("@QuantityInStock", p.QuantityInStock);
                cmd.Parameters.AddWithValue("@ProductDescription", p.ProductDescription);
                cmd.Parameters.AddWithValue("@Photo", string.IsNullOrWhiteSpace(p.Photo) ? (object)DBNull.Value : p.Photo);

                cmd.ExecuteNonQuery();
            }
        }

        public void DeleteProduct(string article)
        {
            if (IsProductUsedInOrders(article))
                throw new InvalidOperationException("Товар присутствует в заказе и не может быть удален.");

            using (SqlConnection con = Open())
            using (SqlCommand cmd = new SqlCommand("DELETE FROM Products WHERE ArticleNumber=@a", con))
            {
                cmd.Parameters.AddWithValue("@a", article);
                cmd.ExecuteNonQuery();
            }
        }

        public bool IsProductUsedInOrders(string article)
        {
            using (SqlConnection con = Open())
            using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM OrderItems WHERE ProductArticleNumber = @a", con))
            {
                cmd.Parameters.AddWithValue("@a", article);
                return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
            }
        }

        public List<OrderView> GetOrders()
        {
            List<OrderView> list = new List<OrderView>();
            string personColumn = GetOrderPersonColumn();

            string sql = @"
SELECT 
    o.OrderNumber,
    CONVERT(nvarchar, o.OrderDate, 104) AS OrderDate,
    CONVERT(nvarchar, o.DeliveryDate, 104) AS DeliveryDate,
    ISNULL(o.StatusId, 2) AS StatusId,
    ISNULL(os.Name, N'Новый') AS StatusName,
    o." + personColumn + @" AS PersonId,
    o.PickupPointAddress AS PickupPointId,
    c.LastName + ' ' + c.FirstName + ' ' + c.MiddleName AS PersonName,
    pp.Address AS PickupAddress,
    ISNULL(o.PickupCode, 0) AS PickupCode,
    COUNT(oi.ProductArticleNumber) AS ItemCount,
    ISNULL(SUM(oi.Quantity * p.Price), 0) AS TotalWithoutDiscount,
    ISNULL(SUM(oi.Quantity * p.Price * (1 - ISNULL(p.CurrentDiscount, 0) / 100.0)), 0) AS TotalWithDiscount,
    ISNULL(
        STUFF((
            SELECT '; ' + p2.ProductName + ' (' + CAST(CAST(oi2.Quantity AS int) AS nvarchar) + ' шт.)'
            FROM OrderItems oi2
            JOIN Products p2 ON p2.ArticleNumber = oi2.ProductArticleNumber
            WHERE oi2.OrderNumber = o.OrderNumber
            FOR XML PATH(''), TYPE
        ).value('.', 'nvarchar(max)'), 1, 2, ''),
    '') AS ProductsText
FROM Orders o
LEFT JOIN OrderStatuses os ON os.Id = o.StatusId
JOIN Persons c ON c.Id = o." + personColumn + @"
JOIN PickupPoints pp ON pp.Id = o.PickupPointAddress
LEFT JOIN OrderItems oi ON oi.OrderNumber = o.OrderNumber
LEFT JOIN Products p ON p.ArticleNumber = oi.ProductArticleNumber
GROUP BY 
    o.OrderNumber,
    o.OrderDate,
    o.DeliveryDate,
    o.StatusId,
    os.Name,
    o." + personColumn + @",
    o.PickupPointAddress,
    c.LastName,
    c.FirstName,
    c.MiddleName,
    pp.Address,
    o.PickupCode
ORDER BY o.OrderNumber";

            using (SqlConnection con = Open())
            using (SqlCommand cmd = new SqlCommand(sql, con))
            using (SqlDataReader r = cmd.ExecuteReader())
            {
                while (r.Read())
                {
                    double totalWithoutDiscount = Convert.ToDouble(r["TotalWithoutDiscount"]);
                    double totalWithDiscount = Convert.ToDouble(r["TotalWithDiscount"]);

                    double discountPercent = 0;

                    if (totalWithoutDiscount > 0)
                        discountPercent = 100 - totalWithDiscount / totalWithoutDiscount * 100;

                    list.Add(new OrderView
                    {
                        OrderNumber = Convert.ToInt32(r["OrderNumber"]),
                        OrderDate = r["OrderDate"].ToString(),
                        DeliveryDate = r["DeliveryDate"].ToString(),
                        StatusId = Convert.ToInt32(r["StatusId"]),
                        StatusName = r["StatusName"].ToString(),
                        PersonId = Convert.ToInt32(r["PersonId"]),
                        PickupPointId = Convert.ToInt32(r["PickupPointId"]),
                        PersonName = r["PersonName"].ToString(),
                        PickupAddress = r["PickupAddress"].ToString(),
                        PickupCode = Convert.ToInt32(r["PickupCode"]),
                        ItemCount = Convert.ToInt32(r["ItemCount"]),
                        Total = totalWithDiscount,
                        ProductsText = r["ProductsText"].ToString(),
                        DiscountPercent = discountPercent
                    });
                }
            }

            return list;
        }

        public int GetNextOrderNumber()
        {
            using (SqlConnection con = Open())
            using (SqlCommand cmd = new SqlCommand("SELECT ISNULL(MAX(OrderNumber), 0) + 1 FROM Orders", con))
            {
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        public List<OrderItemView> GetOrderItems(int orderNumber)
        {
            List<OrderItemView> list = new List<OrderItemView>();

            string sql = @"
SELECT oi.ProductArticleNumber,
       p.ProductName,
       oi.Quantity,
       p.Price,
       ISNULL(p.CurrentDiscount, 0) AS Discount
FROM OrderItems oi
JOIN Products p ON p.ArticleNumber = oi.ProductArticleNumber
WHERE oi.OrderNumber = @OrderNumber";

            using (SqlConnection con = Open())
            using (SqlCommand cmd = new SqlCommand(sql, con))
            {
                cmd.Parameters.AddWithValue("@OrderNumber", orderNumber);

                using (SqlDataReader r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new OrderItemView
                        {
                            ProductArticleNumber = r["ProductArticleNumber"].ToString(),
                            ProductName = r["ProductName"].ToString(),
                            Quantity = Convert.ToDouble(r["Quantity"]),
                            Price = Convert.ToDouble(r["Price"]),
                            Discount = Convert.ToDouble(r["Discount"])
                        });
                    }
                }
            }

            return list;
        }

        // Заказ и его состав сохраняются одной транзакцией, чтобы не получить заказ без товаров.
        public void AddOrder(
            int orderNumber,
            DateTime orderDate,
            DateTime deliveryDate,
            int statusId,
            int pickupPointId,
            int personId,
            int pickupCode,
            List<OrderItemView> items)
        {
            using (SqlConnection con = Open())
            using (SqlTransaction transaction = con.BeginTransaction())
            {
                try
                {
                    string personColumn = GetOrderPersonColumn();

                    string orderSql = @"
INSERT INTO Orders
(OrderNumber, OrderDate, DeliveryDate, StatusId, PickupPointAddress, " + personColumn + @", PickupCode)
VALUES
(@OrderNumber, @OrderDate, @DeliveryDate, @StatusId, @PickupPointAddress, @PersonId, @PickupCode)";

                    using (SqlCommand cmd = new SqlCommand(orderSql, con, transaction))
                    {
                        cmd.Parameters.AddWithValue("@OrderNumber", orderNumber);
                        cmd.Parameters.AddWithValue("@OrderDate", orderDate);
                        cmd.Parameters.AddWithValue("@DeliveryDate", deliveryDate);
                        cmd.Parameters.AddWithValue("@StatusId", statusId);
                        cmd.Parameters.AddWithValue("@PickupPointAddress", pickupPointId);
                        cmd.Parameters.AddWithValue("@PersonId", personId);
                        cmd.Parameters.AddWithValue("@PickupCode", pickupCode);
                        cmd.ExecuteNonQuery();
                    }

                    foreach (OrderItemView item in items)
                    {
                        string itemSql = @"
INSERT INTO OrderItems
(OrderNumber, ProductArticleNumber, Quantity)
VALUES
(@OrderNumber, @ProductArticleNumber, @Quantity)";

                        using (SqlCommand cmd = new SqlCommand(itemSql, con, transaction))
                        {
                            cmd.Parameters.AddWithValue("@OrderNumber", orderNumber);
                            cmd.Parameters.AddWithValue("@ProductArticleNumber", item.ProductArticleNumber);
                            cmd.Parameters.AddWithValue("@Quantity", item.Quantity);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    transaction.Commit();
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        // При редактировании состав заказа пересоздается целиком внутри транзакции.
        public void UpdateOrder(
            int orderNumber,
            DateTime orderDate,
            DateTime deliveryDate,
            int statusId,
            int pickupPointId,
            int personId,
            int pickupCode,
            List<OrderItemView> items)
        {
            using (SqlConnection con = Open())
            using (SqlTransaction transaction = con.BeginTransaction())
            {
                try
                {
                    string personColumn = GetOrderPersonColumn();

                    string orderSql = @"
UPDATE Orders SET
OrderDate = @OrderDate,
DeliveryDate = @DeliveryDate,
StatusId = @StatusId,
PickupPointAddress = @PickupPointAddress,
" + personColumn + @" = @PersonId,
PickupCode = @PickupCode
WHERE OrderNumber = @OrderNumber";

                    using (SqlCommand cmd = new SqlCommand(orderSql, con, transaction))
                    {
                        cmd.Parameters.AddWithValue("@OrderNumber", orderNumber);
                        cmd.Parameters.AddWithValue("@OrderDate", orderDate);
                        cmd.Parameters.AddWithValue("@DeliveryDate", deliveryDate);
                        cmd.Parameters.AddWithValue("@StatusId", statusId);
                        cmd.Parameters.AddWithValue("@PickupPointAddress", pickupPointId);
                        cmd.Parameters.AddWithValue("@PersonId", personId);
                        cmd.Parameters.AddWithValue("@PickupCode", pickupCode);
                        cmd.ExecuteNonQuery();
                    }

                    using (SqlCommand cmd = new SqlCommand("DELETE FROM OrderItems WHERE OrderNumber = @OrderNumber", con, transaction))
                    {
                        cmd.Parameters.AddWithValue("@OrderNumber", orderNumber);
                        cmd.ExecuteNonQuery();
                    }

                    foreach (OrderItemView item in items)
                    {
                        string itemSql = @"
INSERT INTO OrderItems
(OrderNumber, ProductArticleNumber, Quantity)
VALUES
(@OrderNumber, @ProductArticleNumber, @Quantity)";

                        using (SqlCommand cmd = new SqlCommand(itemSql, con, transaction))
                        {
                            cmd.Parameters.AddWithValue("@OrderNumber", orderNumber);
                            cmd.Parameters.AddWithValue("@ProductArticleNumber", item.ProductArticleNumber);
                            cmd.Parameters.AddWithValue("@Quantity", item.Quantity);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    transaction.Commit();
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        public void DeleteOrder(int orderNumber)
        {
            using (SqlConnection con = Open())
            using (SqlTransaction transaction = con.BeginTransaction())
            {
                try
                {
                    using (SqlCommand cmd = new SqlCommand("DELETE FROM OrderItems WHERE OrderNumber = @OrderNumber", con, transaction))
                    {
                        cmd.Parameters.AddWithValue("@OrderNumber", orderNumber);
                        cmd.ExecuteNonQuery();
                    }

                    using (SqlCommand cmd = new SqlCommand("DELETE FROM Orders WHERE OrderNumber = @OrderNumber", con, transaction))
                    {
                        cmd.Parameters.AddWithValue("@OrderNumber", orderNumber);
                        cmd.ExecuteNonQuery();
                    }

                    transaction.Commit();
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }
    }
}
