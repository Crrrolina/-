namespace ToysStore
{
    public enum UserRole
    {
        Guest = 0,
        Admin = 1,
        Manager = 2,
        Client = 3
    }

    public class CurrentUser
    {
        public int Id { get; set; }
        public string Login { get; set; }
        public string FullName { get; set; }
        public UserRole Role { get; set; }

        public CurrentUser()
        {
            FullName = "Гость";
            Role = UserRole.Guest;
        }

        public string RoleName
        {
            get
            {
                if (Role == UserRole.Admin) return "Администратор";
                if (Role == UserRole.Manager) return "Менеджер";
                if (Role == UserRole.Client) return "Клиент";
                return "Неавторизованный пользователь";
            }
        }
    }

    public class Product
    {
        public string ArticleNumber { get; set; }
        public string ProductName { get; set; }
        public int Unit { get; set; }
        public double Price { get; set; }
        public int Supplier { get; set; }
        public int Manufacturer { get; set; }
        public int ProductCategory { get; set; }
        public double CurrentDiscount { get; set; }
        public double QuantityInStock { get; set; }
        public string ProductDescription { get; set; }
        public string Photo { get; set; }

        public string UnitName { get; set; }
        public string SupplierName { get; set; }
        public string ManufacturerName { get; set; }
        public string CategoryName { get; set; }

        public string DisplayText
        {
            get
            {
                return ArticleNumber + " | " + CategoryName + " | " + ProductName + " | " + Price.ToString("N2") + " руб.";
            }
        }

        public override string ToString()
        {
            return ArticleNumber + " | " + ProductName;
        }
    }

    public class LookupItem
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public override string ToString()
        {
            return Name;
        }
    }

    public class OrderView
    {
        public int OrderNumber { get; set; }
        public string OrderDate { get; set; }
        public string DeliveryDate { get; set; }
        public int StatusId { get; set; }
        public string StatusName { get; set; }
        public int PersonId { get; set; }
        public int PickupPointId { get; set; }
        public string PersonName { get; set; }
        public string PickupAddress { get; set; }
        public int PickupCode { get; set; }
        public int ItemCount { get; set; }
        public double Total { get; set; }
        public string ProductsText { get; set; }
        public double DiscountPercent { get; set; }
    }

    public class OrderItemView
    {
        public string ProductArticleNumber { get; set; }
        public string ProductName { get; set; }
        public double Quantity { get; set; }
        public double Price { get; set; }
        public double Discount { get; set; }

        public double Total
        {
            get
            {
                return Quantity * Price * (1 - Discount / 100.0);
            }
        }
    }
}
