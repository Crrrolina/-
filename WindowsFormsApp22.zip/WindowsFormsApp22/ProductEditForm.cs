using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;

namespace ToysStore
{
    public partial class ProductEditForm : Form
    {
        private readonly Db db = new Db();
        private readonly Product product;
        private readonly bool isNew;
        private string selectedPhotoPath = "";
        private string originalPhoto = "";

        public ProductEditForm(Product selectedProduct)
        {
            product = selectedProduct;
            isNew = product == null;

            InitializeComponent();
            LoadFormIcon();

            Text = isNew ? "Добавление товара" : "Редактирование товара";

            try
            {
                LoadLookups();

                if (!isNew)
                    FillFields();
                else
                    LoadPhotoPreview("");
            }
            catch (Exception ex)
            {
                MessageHelper.Error(
                    "Не удалось загрузить данные для формы товара.\n\n" +
                    "Проверьте подключение к базе данных и наличие справочников: Units, Suppliers, Manufacturers, Categories.\n\n" +
                    "Техническая информация:\n" + ex.Message);
                Close();
            }
        }

        private void LoadFormIcon()
        {
            string iconPath = Path.Combine(Application.StartupPath, "Images", "Icon.ico");

            if (!File.Exists(iconPath))
                return;

            try
            {
                Icon = new Icon(iconPath);
            }
            catch
            {
                Icon = null;
            }
        }

        private void LoadLookups()
        {
            FillCombo(cmbUnit, "Units");
            FillCombo(cmbSupplier, "Suppliers");
            FillCombo(cmbManufacturer, "Manufacturers");
            FillCombo(cmbCategory, "Categories");
        }

        private void FillCombo(ComboBox combo, string table)
        {
            combo.DataSource = db.GetLookup(table);
            combo.DisplayMember = "Name";
            combo.ValueMember = "Id";
        }

        private void FillFields()
        {
            txtArticle.Text = product.ArticleNumber;
            txtArticle.ReadOnly = true;

            txtName.Text = product.ProductName;
            cmbUnit.SelectedValue = product.Unit;
            txtPrice.Text = product.Price.ToString();
            cmbSupplier.SelectedValue = product.Supplier;
            cmbManufacturer.SelectedValue = product.Manufacturer;
            cmbCategory.SelectedValue = product.ProductCategory;
            txtDiscount.Text = product.CurrentDiscount.ToString();
            txtStock.Text = product.QuantityInStock.ToString();
            txtDescription.Text = product.ProductDescription;
            txtPhoto.Text = product.Photo;
            originalPhoto = product.Photo;
            LoadPhotoPreview(product.Photo);
        }

        private void btnSelectPhoto_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                // Выбранное фото будет скопировано в Images и приведено к размеру 300x200.
                dialog.Title = "Выбор изображения товара";
                dialog.Filter = "Изображения|*.jpg;*.jpeg;*.png;*.bmp|Все файлы|*.*";

                if (dialog.ShowDialog() != DialogResult.OK)
                    return;

                try
                {
                    using (Image.FromFile(dialog.FileName))
                    {
                    }

                    selectedPhotoPath = dialog.FileName;
                    txtPhoto.Text = Path.GetFileName(dialog.FileName);
                    LoadPhotoPreview(selectedPhotoPath);
                }
                catch (Exception ex)
                {
                    MessageHelper.Warning(
                        "Выбранный файл не удалось открыть как изображение.\n\n" +
                        "Выберите файл формата JPG, JPEG, PNG или BMP.\n\n" +
                        "Техническая информация:\n" + ex.Message);
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateInput(out Product p))
                return;

            try
            {
                p.Photo = SaveSelectedPhotoIfNeeded();

                if (isNew)
                    db.AddProduct(p);
                else
                    db.UpdateProduct(p);

                DeleteOldPhotoIfNeeded(p.Photo);

                MessageHelper.Info("Данные товара успешно сохранены.");
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageHelper.Error(
                    "Не удалось сохранить товар.\n\n" +
                    "Проверьте, что артикул уникален, все обязательные поля заполнены, " +
                    "а база данных доступна.\n\n" +
                    "Техническая информация:\n" + ex.Message);
            }
        }

        private bool ValidateInput(out Product p)
        {
            p = null;

            if (txtArticle.Text.Trim() == "")
            {
                MessageHelper.Warning(
                    "Не заполнен артикул товара.\n\n" +
                    "Введите уникальный артикул товара и повторите сохранение.");
                txtArticle.Focus();
                return false;
            }

            if (txtName.Text.Trim() == "")
            {
                MessageHelper.Warning(
                    "Не заполнено наименование товара.\n\n" +
                    "Введите название товара и повторите сохранение.");
                txtName.Focus();
                return false;
            }

            if (!double.TryParse(txtPrice.Text, out double price) || price < 0)
            {
                MessageHelper.Warning(
                    "Некорректная цена товара.\n\n" +
                    "Введите положительное число. Например: 2500 или 2500,50.");
                txtPrice.Focus();
                return false;
            }

            if (!double.TryParse(txtDiscount.Text, out double discount) || discount < 0 || discount > 100)
            {
                MessageHelper.Warning(
                    "Некорректная скидка.\n\n" +
                    "Введите число от 0 до 100.");
                txtDiscount.Focus();
                return false;
            }

            if (!double.TryParse(txtStock.Text, out double stock) || stock < 0)
            {
                MessageHelper.Warning(
                    "Некорректное количество товара на складе.\n\n" +
                    "Введите число 0 или больше.");
                txtStock.Focus();
                return false;
            }

            if (cmbUnit.SelectedValue == null ||
                cmbSupplier.SelectedValue == null ||
                cmbManufacturer.SelectedValue == null ||
                cmbCategory.SelectedValue == null)
            {
                MessageHelper.Warning(
                    "Не выбраны справочные данные товара.\n\n" +
                    "Выберите единицу измерения, поставщика, производителя и категорию.");
                return false;
            }

            p = new Product
            {
                ArticleNumber = txtArticle.Text.Trim(),
                ProductName = txtName.Text.Trim(),
                Unit = Convert.ToInt32(cmbUnit.SelectedValue),
                Price = price,
                Supplier = Convert.ToInt32(cmbSupplier.SelectedValue),
                Manufacturer = Convert.ToInt32(cmbManufacturer.SelectedValue),
                ProductCategory = Convert.ToInt32(cmbCategory.SelectedValue),
                CurrentDiscount = discount,
                QuantityInStock = stock,
                ProductDescription = txtDescription.Text.Trim(),
                Photo = txtPhoto.Text.Trim()
            };

            return true;
        }

        private string SaveSelectedPhotoIfNeeded()
        {
            if (string.IsNullOrWhiteSpace(selectedPhotoPath))
                return txtPhoto.Text.Trim();

            string imagesFolder = Path.Combine(Application.StartupPath, "Images");
            Directory.CreateDirectory(imagesFolder);

            // Имя файла сохраняем, но убираем символы, запрещенные в именах файлов Windows.
            string extension = Path.GetExtension(selectedPhotoPath).ToLower();
            if (extension == "")
                extension = ".jpg";

            string fileName = MakeSafeFileName(Path.GetFileName(selectedPhotoPath));
            if (Path.GetExtension(fileName) == "")
                fileName += extension;

            string destinationPath = Path.Combine(imagesFolder, fileName);
            string tempPath = Path.Combine(imagesFolder, Guid.NewGuid().ToString("N") + extension);

            using (Image source = Image.FromFile(selectedPhotoPath))
            using (Image resized = ResizeImage(source, 300, 200))
            {
                ImageFormat format = ImageFormat.Jpeg;

                if (extension == ".png")
                    format = ImageFormat.Png;
                else if (extension == ".bmp")
                    format = ImageFormat.Bmp;

                resized.Save(tempPath, format);
            }

            File.Copy(tempPath, destinationPath, true);
            File.Delete(tempPath);

            return fileName;
        }

        private Image ResizeImage(Image source, int maxWidth, int maxHeight)
        {
            Bitmap result = new Bitmap(maxWidth, maxHeight);

            // Фото вписывается в 300x200 без искажения пропорций.
            using (Graphics graphics = Graphics.FromImage(result))
            {
                graphics.Clear(Color.White);
                graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;

                double ratio = Math.Min((double)maxWidth / source.Width, (double)maxHeight / source.Height);
                int width = (int)(source.Width * ratio);
                int height = (int)(source.Height * ratio);
                int x = (maxWidth - width) / 2;
                int y = (maxHeight - height) / 2;

                graphics.DrawImage(source, x, y, width, height);
            }

            return result;
        }

        private void DeleteOldPhotoIfNeeded(string newPhoto)
        {
            if (isNew || string.IsNullOrWhiteSpace(originalPhoto))
                return;

            // При замене фото старый файл из Images удаляется, кроме служебных картинок.
            if (string.Equals(originalPhoto, newPhoto, StringComparison.OrdinalIgnoreCase))
                return;

            if (IsDefaultImage(originalPhoto))
                return;

            string oldPath = Path.Combine(Application.StartupPath, "Images", originalPhoto);

            if (File.Exists(oldPath))
                File.Delete(oldPath);
        }

        private bool IsDefaultImage(string photo)
        {
            return string.Equals(photo, "picture.png", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(photo, "Icon.png", StringComparison.OrdinalIgnoreCase);
        }

        private string MakeSafeFileName(string value)
        {
            foreach (char c in Path.GetInvalidFileNameChars())
                value = value.Replace(c, '_');

            return value;
        }

        private void LoadPhotoPreview(string photo)
        {
            // Для отсутствующего или поврежденного фото показывается заглушка picture.png.
            string imagePath = "";

            if (!string.IsNullOrWhiteSpace(photo))
            {
                if (Path.IsPathRooted(photo) && File.Exists(photo))
                    imagePath = photo;
                else
                {
                    string productPath = Path.Combine(Application.StartupPath, "Images", photo);

                    if (File.Exists(productPath))
                        imagePath = productPath;
                }
            }

            string stubPath = Path.Combine(Application.StartupPath, "Images", "picture.png");

            if (string.IsNullOrWhiteSpace(imagePath) && File.Exists(stubPath))
                imagePath = stubPath;

            Image preview = TryLoadImageCopy(imagePath);

            if (preview == null && File.Exists(stubPath))
                preview = TryLoadImageCopy(stubPath);

            if (picPhoto.Image != null)
            {
                Image oldImage = picPhoto.Image;
                picPhoto.Image = null;
                oldImage.Dispose();
            }

            picPhoto.Image = preview;
        }

        private Image TryLoadImageCopy(string imagePath)
        {
            if (string.IsNullOrWhiteSpace(imagePath))
                return null;

            try
            {
                using (FileStream fs = new FileStream(imagePath, FileMode.Open, FileAccess.Read))
                using (Image temp = Image.FromStream(fs))
                {
                    return new Bitmap(temp);
                }
            }
            catch
            {
                return null;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
    }
}
