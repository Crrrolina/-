﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace ToysStore
{
    public partial class LoginForm : Form
    {
        private Db db = new Db();

        public LoginForm()
        {
            InitializeComponent();
            LoadBrandAssets();
        }

        private void LoadBrandAssets()
        {
            LoadFormIcon();

            string logoPath = Path.Combine(Application.StartupPath, "Images", "Icon.png");

            if (!File.Exists(logoPath))
                return;

            try
            {
                using (FileStream fs = new FileStream(logoPath, FileMode.Open, FileAccess.Read))
                using (Image temp = Image.FromStream(fs))
                {
                    pictureLogo.Image = new Bitmap(temp);
                }
            }
            catch
            {
                pictureLogo.Image = null;
            }
        }

        private void LoadFormIcon()
        {
            string iconPath = Path.Combine(Application.StartupPath, "Images", "Icon.ico");

            if (!File.Exists(iconPath))
                return;

            try
            {
                Icon = new Icon(iconPath);
            }
            catch
            {
                Icon = null;
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtLogin.Text.Trim() == "")
            {
                MessageHelper.Warning(
                    "Не введен логин.\n\n" +
                    "Введите логин пользователя или войдите как гость.");
                txtLogin.Focus();
                return;
            }

            if (txtPassword.Text.Trim() == "")
            {
                MessageHelper.Warning(
                    "Не введен пароль.\n\n" +
                    "Введите пароль пользователя или войдите как гость.");
                txtPassword.Focus();
                return;
            }

            try
            {
                CurrentUser user = db.Login(txtLogin.Text.Trim(), txtPassword.Text);

                if (user == null)
                {
                    MessageHelper.Warning(
                        "Неверный логин или пароль.\n\n" +
                        "Проверьте правильность введенных данных и попробуйте снова.\n" +
                        "Если у вас нет учетной записи, используйте вход как гость.");
                    return;
                }

                ProductsForm form = new ProductsForm(user);
                // Окно входа прячется, чтобы после выхода из аккаунта снова показать его через Show().
                Hide();
                form.ShowDialog();
                Show();
            }
            catch (Exception ex)
            {
                MessageHelper.Error(
                    "Не удалось подключиться к базе данных.\n\n" +
                    "Проверьте, что SQL Server запущен, база данных существует, " +
                    "а строка подключения указана правильно.\n\n" +
                    "Техническая информация:\n" + ex.Message);
            }
        }

        private void btnGuest_Click(object sender, EventArgs e)
        {
            ProductsForm form = new ProductsForm(new CurrentUser());
            Hide();
            form.ShowDialog();
            Show();
        }

        private void lblTitle_Click(object sender, EventArgs e)
        {

        }
    }
}
