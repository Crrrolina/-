﻿using System.Drawing;
using System.Windows.Forms;

namespace ToysStore
{
    partial class OrdersForm
    {
        private System.ComponentModel.IContainer components = null;

        private Label lblHeader;
        private FlowLayoutPanel panelOrders;
        private Panel panelButtons;

        private Button btnAdd;
        private Button btnEdit;
        private Button btnDelete;
        private Button btnRefresh;
        private Button btnBack;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblHeader = new Label();
            this.panelOrders = new FlowLayoutPanel();
            this.panelButtons = new Panel();

            this.btnAdd = new Button();
            this.btnEdit = new Button();
            this.btnDelete = new Button();
            this.btnRefresh = new Button();
            this.btnBack = new Button();

            this.SuspendLayout();

            this.Text = "Заказы";
            this.ClientSize = new Size(1000, 650);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font = new Font("Times New Roman", 11F);
            this.BackColor = Color.White;

            this.lblHeader.Text = "Заказы";
            this.lblHeader.Dock = DockStyle.Top;
            this.lblHeader.Height = 45;
            this.lblHeader.Font = new Font("Times New Roman", 16F, FontStyle.Bold);
            this.lblHeader.BackColor = ColorTranslator.FromHtml("#7FFF00");
            this.lblHeader.TextAlign = ContentAlignment.MiddleLeft;
            this.lblHeader.Padding = new Padding(10, 0, 0, 0);

            this.panelButtons.Dock = DockStyle.Bottom;
            this.panelButtons.Height = 55;
            this.panelButtons.BackColor = Color.White;

            this.btnAdd.Text = "Добавить заказ";
            this.btnAdd.Location = new Point(10, 12);
            this.btnAdd.Size = new Size(140, 32);
            this.btnAdd.BackColor = ColorTranslator.FromHtml("#00FA9A");
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);

            this.btnEdit.Text = "Редактировать";
            this.btnEdit.Location = new Point(160, 12);
            this.btnEdit.Size = new Size(130, 32);
            this.btnEdit.BackColor = ColorTranslator.FromHtml("#00FA9A");
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);

            this.btnDelete.Text = "Удалить";
            this.btnDelete.Location = new Point(300, 12);
            this.btnDelete.Size = new Size(110, 32);
            this.btnDelete.BackColor = Color.LightCoral;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);

            this.btnRefresh.Text = "Обновить";
            this.btnRefresh.Location = new Point(420, 12);
            this.btnRefresh.Size = new Size(110, 32);
            this.btnRefresh.BackColor = ColorTranslator.FromHtml("#00FA9A");
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);

            this.btnBack.Text = "Назад";
            this.btnBack.Location = new Point(540, 12);
            this.btnBack.Size = new Size(110, 32);
            this.btnBack.BackColor = ColorTranslator.FromHtml("#7FFF00");
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);

            this.panelButtons.Controls.Add(this.btnAdd);
            this.panelButtons.Controls.Add(this.btnEdit);
            this.panelButtons.Controls.Add(this.btnDelete);
            this.panelButtons.Controls.Add(this.btnRefresh);
            this.panelButtons.Controls.Add(this.btnBack);

            this.panelOrders.Dock = DockStyle.Fill;
            this.panelOrders.AutoScroll = true;
            this.panelOrders.BackColor = Color.White;
            this.panelOrders.Padding = new Padding(15);
            this.panelOrders.FlowDirection = FlowDirection.TopDown;
            this.panelOrders.WrapContents = false;

            this.Controls.Add(this.panelOrders);
            this.Controls.Add(this.panelButtons);
            this.Controls.Add(this.lblHeader);

            this.ResumeLayout(false);
        }
    }
}