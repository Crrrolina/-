﻿using System.Windows.Forms;

namespace ToysStore
{
    public static class MessageHelper
    {
        public static void Error(string text)
        {
            MessageBox.Show(
                text,
                "Ошибка",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }

        public static void Warning(string text)
        {
            MessageBox.Show(
                text,
                "Предупреждение",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
        }

        public static void Info(string text)
        {
            MessageBox.Show(
                text,
                "Информация",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        public static bool Confirm(string text)
        {
            return MessageBox.Show(
                text,
                "Подтверждение действия",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes;
        }
    }
}