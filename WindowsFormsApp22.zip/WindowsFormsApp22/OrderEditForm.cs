﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace ToysStore
{
    public partial class OrderEditForm : Form
    {
        private Db db = new Db();
        private OrderView order;
        private bool isNew;

        private List<Product> products = new List<Product>();
        private List<OrderItemView> items = new List<OrderItemView>();
        // BindingSource нужен, чтобы DataGridView нормально обновлялся после изменения списка items.
        private BindingSource itemsBindingSource = new BindingSource();

        public OrderEditForm(OrderView selectedOrder)
        {
            order = selectedOrder;
            isNew = order == null;

            InitializeComponent();
            LoadFormIcon();

            try
            {
                LoadLookups();

                if (isNew)
                    PrepareNewOrder();
                else
                    LoadExistingOrder();
            }
            catch (Exception ex)
            {
                MessageHelper.Error(
                    "Не удалось открыть форму заказа.\n\n" +
                    "Проверьте подключение к базе данных и наличие справочников пользователей, пунктов выдачи и товаров.\n\n" +
                    "Техническая информация:\n" + ex.Message);
                Close();
            }
        }

        private void LoadFormIcon()
        {
            string iconPath = Path.Combine(Application.StartupPath, "Images", "Icon.ico");

            if (!File.Exists(iconPath))
                return;

            try
            {
                Icon = new Icon(iconPath);
            }
            catch
            {
                Icon = null;
            }
        }

        private void LoadLookups()
        {
            cmbClient.DataSource = db.GetLookup("Persons");
            cmbClient.DisplayMember = "Name";
            cmbClient.ValueMember = "Id";

            cmbPickupPoint.DataSource = db.GetLookup("PickupPoints");
            cmbPickupPoint.DisplayMember = "Name";
            cmbPickupPoint.ValueMember = "Id";

            cmbStatus.DataSource = db.GetLookup("OrderStatuses");
            cmbStatus.DisplayMember = "Name";
            cmbStatus.ValueMember = "Id";

            products = db.GetProducts();

            cmbProduct.DataSource = products;
            cmbProduct.DisplayMember = "DisplayText";
            cmbProduct.ValueMember = "ArticleNumber";
        }

        private void PrepareNewOrder()
        {
            lblTitle.Text = "Добавление заказа";

            txtNumber.Text = db.GetNextOrderNumber().ToString();
            txtPickupCode.Text = new Random().Next(100, 999).ToString();

            dtpOrderDate.Value = DateTime.Today;
            dtpDeliveryDate.Value = DateTime.Today.AddDays(3);
            cmbStatus.SelectedValue = 2;

            RenderItems();
        }

        private void LoadExistingOrder()
        {
            lblTitle.Text = "Редактирование заказа №" + order.OrderNumber;

            txtNumber.Text = order.OrderNumber.ToString();
            txtPickupCode.Text = order.PickupCode.ToString();
            cmbClient.SelectedValue = order.PersonId;
            cmbPickupPoint.SelectedValue = order.PickupPointId;
            cmbStatus.SelectedValue = order.StatusId;

            DateTime orderDate;
            if (DateTime.TryParse(order.OrderDate, out orderDate))
                dtpOrderDate.Value = orderDate;

            DateTime deliveryDate;
            if (DateTime.TryParse(order.DeliveryDate, out deliveryDate))
                dtpDeliveryDate.Value = deliveryDate;

            items = db.GetOrderItems(order.OrderNumber);

            RenderItems();
        }

        private void btnAddItem_Click(object sender, EventArgs e)
        {
            if (cmbProduct.SelectedItem == null)
            {
                MessageHelper.Warning(
                    "Товар не выбран.\n\n" +
                    "Выберите товар из списка и повторите добавление.");
                return;
            }

            double quantity;

            if (!double.TryParse(txtQuantity.Text, out quantity) || quantity <= 0)
            {
                MessageHelper.Warning(
                    "Некорректное количество товара.\n\n" +
                    "Введите число больше 0. Например: 1 или 2.");
                txtQuantity.Focus();
                return;
            }

            Product product = cmbProduct.SelectedItem as Product;

            if (product == null)
            {
                MessageHelper.Warning(
                    "Не удалось определить выбранный товар.\n\n" +
                    "Выберите товар из списка повторно.");
                return;
            }

            OrderItemView existing = items.FirstOrDefault(x => x.ProductArticleNumber == product.ArticleNumber);

            if (existing != null)
            {
                existing.Quantity += quantity;
            }
            else
            {
                items.Add(new OrderItemView
                {
                    ProductArticleNumber = product.ArticleNumber,
                    ProductName = product.ProductName,
                    Quantity = quantity,
                    Price = product.Price,
                    Discount = product.CurrentDiscount
                });
            }

            RenderItems();
        }

        private void btnRemoveItem_Click(object sender, EventArgs e)
        {
            if (gridItems.SelectedRows.Count == 0 && gridItems.CurrentRow == null)
            {
                MessageHelper.Warning(
                    "Строка состава заказа не выбрана.\n\n" +
                    "Выберите товар в таблице состава заказа и повторите удаление.");
                return;
            }

            DataGridViewRow selectedRow = gridItems.SelectedRows.Count > 0
                ? gridItems.SelectedRows[0]
                : gridItems.CurrentRow;

            // Удаляем именно объект из привязанного списка, а не просто визуальную строку таблицы.
            OrderItemView item = selectedRow.DataBoundItem as OrderItemView;

            if (item == null)
            {
                MessageHelper.Warning(
                    "Не удалось найти выбранный товар в составе заказа.\n\n" +
                    "Обновите форму и повторите действие.");
                return;
            }

            if (MessageHelper.Confirm(
                "Удалить товар \"" + item.ProductName + "\" из состава заказа?\n\n" +
                "Это действие изменит итоговую сумму заказа."))
            {
                items.Remove(item);
                RenderItems();
            }
        }

        private void RenderItems()
        {
            ConfigureItemsGrid();

            itemsBindingSource.DataSource = null;
            itemsBindingSource.DataSource = items;
            gridItems.DataSource = itemsBindingSource;

            gridItems.ClearSelection();

            lblTotal.Text = "Итого: " + items.Sum(x => x.Total).ToString("N2") + " руб.";
        }

        private void ConfigureItemsGrid()
        {
            if (gridItems.Columns.Count > 0)
                return;

            gridItems.AutoGenerateColumns = false;

            AddGridColumn("ProductArticleNumber", "Артикул", "ProductArticleNumber");
            AddGridColumn("ProductName", "Товар", "ProductName");
            AddGridColumn("Quantity", "Количество", "Quantity");
            AddGridColumn("Price", "Цена", "Price");
            AddGridColumn("Discount", "Скидка", "Discount");
            AddGridColumn("Total", "Сумма", "Total");
        }

        private void AddGridColumn(string name, string header, string propertyName)
        {
            DataGridViewTextBoxColumn column = new DataGridViewTextBoxColumn();
            column.Name = name;
            column.HeaderText = header;
            column.DataPropertyName = propertyName;
            column.ReadOnly = true;

            gridItems.Columns.Add(column);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (items.Count == 0)
            {
                MessageHelper.Warning(
                    "В заказе нет товаров.\n\n" +
                    "Добавьте хотя бы один товар в состав заказа и повторите сохранение.");
                return;
            }

            int pickupCode;

            if (!int.TryParse(txtPickupCode.Text, out pickupCode))
            {
                MessageHelper.Warning(
                    "Некорректный код получения.\n\n" +
                    "Введите числовой код получения, например 123.");
                txtPickupCode.Focus();
                return;
            }

            if (cmbClient.SelectedValue == null)
            {
                MessageHelper.Warning(
                    "Не выбран пользователь.\n\n" +
                    "Выберите пользователя из списка.");
                return;
            }

            if (cmbPickupPoint.SelectedValue == null)
            {
                MessageHelper.Warning(
                    "Не выбран пункт выдачи.\n\n" +
                    "Выберите пункт выдачи из списка.");
                return;
            }

            if (cmbStatus.SelectedValue == null)
            {
                MessageHelper.Warning(
                    "Не выбран статус заказа.\n\n" +
                    "Выберите статус заказа из списка.");
                return;
            }

            if (dtpDeliveryDate.Value.Date < dtpOrderDate.Value.Date)
            {
                MessageHelper.Warning(
                    "Дата доставки не может быть раньше даты заказа.\n\n" +
                    "Измените дату доставки и повторите сохранение.");
                dtpDeliveryDate.Focus();
                return;
            }

            try
            {
                int orderNumber = Convert.ToInt32(txtNumber.Text);
                int personId = Convert.ToInt32(cmbClient.SelectedValue);
                int pickupPointId = Convert.ToInt32(cmbPickupPoint.SelectedValue);
                int statusId = Convert.ToInt32(cmbStatus.SelectedValue);

                if (isNew)
                {
                    db.AddOrder(
                        orderNumber,
                        dtpOrderDate.Value,
                        dtpDeliveryDate.Value,
                        statusId,
                        pickupPointId,
                        personId,
                        pickupCode,
                        items);
                }
                else
                {
                    db.UpdateOrder(
                        orderNumber,
                        dtpOrderDate.Value,
                        dtpDeliveryDate.Value,
                        statusId,
                        pickupPointId,
                        personId,
                        pickupCode,
                        items);
                }

                MessageHelper.Info("Заказ успешно сохранен.");
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageHelper.Error(
                    "Не удалось сохранить заказ.\n\n" +
                    "Проверьте заполнение всех полей, наличие товаров в заказе " +
                    "и подключение к базе данных.\n\n" +
                    "Техническая информация:\n" + ex.Message);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
    }
}


