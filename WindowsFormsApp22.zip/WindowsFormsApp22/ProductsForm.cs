﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace ToysStore
{
    public partial class ProductsForm : Form
    {
        private CurrentUser user;
        private Db db = new Db();
        private List<Product> products = new List<Product>();
        private bool isProductEditFormOpen = false;

        public ProductsForm(CurrentUser currentUser)
        {
            user = currentUser;
            InitializeComponent();
            LoadFormIcon();
            LoadBrandAssets();

            lblHeader.Text = "Товары";
            lblUserInfo.Text = user.FullName + " (" + user.RoleName + ")";
            lblUserInfo.BringToFront();
            picLogo.BringToFront();
            lblUserInfo.BringToFront();

            // Права в интерфейсе завязаны на роль: гость, менеджер, администратор.
            bool extended = user.Role == UserRole.Manager || user.Role == UserRole.Admin;

            txtSearch.Enabled = extended;
            cmbSupplier.Enabled = extended;
            cmbSort.Enabled = extended;

            btnAdd.Visible = user.Role == UserRole.Admin;
            btnEdit.Visible = user.Role == UserRole.Admin;
            btnDelete.Visible = user.Role == UserRole.Admin;
            btnOrders.Visible = user.Role == UserRole.Admin || user.Role == UserRole.Manager;

            LoadSuppliers();
            LoadProducts();
        }

        private void LoadBrandAssets()
        {
            string imagesFolder = Path.Combine(Application.StartupPath, "Images");
            string logoPath = Path.Combine(imagesFolder, "Icon.png");

            if (File.Exists(logoPath))
            {
                using (FileStream fs = new FileStream(logoPath, FileMode.Open, FileAccess.Read))
                using (Image temp = Image.FromStream(fs))
                {
                    picLogo.Image = new Bitmap(temp);
                }
            }
        }

        private void LoadFormIcon()
        {
            string iconPath = Path.Combine(Application.StartupPath, "Images", "Icon.ico");

            if (!File.Exists(iconPath))
                return;

            try
            {
                Icon = new Icon(iconPath);
            }
            catch
            {
                Icon = null;
            }
        }

        private void LoadSuppliers()
        {
            cmbSupplier.Items.Clear();
            cmbSupplier.Items.Add(new LookupItem { Id = 0, Name = "Все поставщики" });

            List<LookupItem> suppliers = db.GetLookup("Suppliers");

            foreach (LookupItem supplier in suppliers)
                cmbSupplier.Items.Add(supplier);

            cmbSupplier.SelectedIndex = 0;
        }

        private void LoadProducts()
        {
            try
            {
                products = db.GetProducts();
                RenderProducts();
            }
            catch (Exception ex)
            {
                MessageHelper.Error(
                    "Не удалось загрузить список товаров.\n\n" +
                    "Проверьте подключение к базе данных и наличие таблиц Products, Units, Suppliers, Manufacturers, Categories.\n\n" +
                    "Техническая информация:\n" + ex.Message);
            }
        }

        private void FilterChanged(object sender, EventArgs e)
        {
            if (products == null)
                return;

            RenderProducts();
        }

        private void RenderProducts()
        {
            IEnumerable<Product> query = products;

            if (user.Role == UserRole.Manager || user.Role == UserRole.Admin)
            {
                string search = txtSearch.Text.Trim().ToLower();

                if (search.Length > 0)
                {
                    string[] words = search.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                    query = query.Where(p =>
                    {
                        string allText =
                            (p.ArticleNumber + " " +
                             p.ProductName + " " +
                             p.ProductDescription + " " +
                             p.Photo + " " +
                             p.UnitName + " " +
                             p.SupplierName + " " +
                             p.ManufacturerName + " " +
                             p.CategoryName).ToLower();

                        foreach (string word in words)
                        {
                            if (!allText.Contains(word))
                                return false;
                        }

                        return true;
                    });
                }

                LookupItem selectedSupplier = cmbSupplier.SelectedItem as LookupItem;

                if (selectedSupplier != null && selectedSupplier.Id != 0)
                {
                    query = query.Where(p => p.Supplier == selectedSupplier.Id);
                }

                if (cmbSort.SelectedIndex == 1)
                    query = query.OrderBy(p => p.QuantityInStock);

                if (cmbSort.SelectedIndex == 2)
                    query = query.OrderByDescending(p => p.QuantityInStock);
            }

            List<Product> result = query.ToList();

            lblCount.Text = result.Count + " из " + products.Count;

            panelProducts.Controls.Clear();
            panelProducts.Tag = null;

            foreach (Product p in result)
                panelProducts.Controls.Add(CreateCard(p));
        }

        private Panel CreateCard(Product p)
        {
            Color cardColor = GetCardColor(p);

            // Разметка карточки повторяет макет задания: фото, данные товара, блок скидки.
            Panel card = new Panel();
            card.Width = 900;
            card.Height = 185;
            card.Margin = new Padding(10);
            card.BorderStyle = BorderStyle.FixedSingle;
            card.Tag = p;
            card.BackColor = cardColor;

            Panel photoBlock = new Panel();
            photoBlock.Location = new Point(18, 12);
            photoBlock.Size = new Size(245, 160);
            photoBlock.BorderStyle = BorderStyle.FixedSingle;
            photoBlock.BackColor = cardColor;
            photoBlock.Tag = p;

            PictureBox pic = new PictureBox();
            pic.Location = new Point(18, 18);
            pic.Size = new Size(210, 124);
            pic.SizeMode = PictureBoxSizeMode.Zoom;
            pic.Image = LoadProductImage(p.Photo);
            pic.Tag = p;

            Label photoText = new Label();
            photoText.Text = "Фото";
            photoText.Location = new Point(88, 65);
            photoText.Size = new Size(70, 30);
            photoText.TextAlign = ContentAlignment.MiddleCenter;
            photoText.BorderStyle = BorderStyle.FixedSingle;
            photoText.BackColor = Color.White;
            photoText.Visible = pic.Image == null;
            photoText.Tag = p;
            photoBlock.Controls.Add(pic);
            photoBlock.Controls.Add(photoText);

            Panel infoBlock = new Panel();
            infoBlock.Location = new Point(272, 12);
            infoBlock.Size = new Size(465, 160);
            infoBlock.BorderStyle = BorderStyle.FixedSingle;
            infoBlock.BackColor = cardColor;
            infoBlock.Tag = p;

            Label lblTitle = new Label();
            lblTitle.Location = new Point(10, 8);
            lblTitle.Size = new Size(445, 23);
            lblTitle.Font = new Font("Times New Roman", 11F, FontStyle.Bold);
            lblTitle.Text = p.CategoryName + " | " + p.ProductName;
            lblTitle.AutoEllipsis = true;
            lblTitle.Tag = p;

            Label lblDescription = CreateInfoLabel("Описание товара: " + p.ProductDescription, 10, 31, 445, 22, p);
            Label lblManufacturer = CreateInfoLabel("Производитель: " + p.ManufacturerName, 10, 53, 445, 22, p);
            Label lblSupplier = CreateInfoLabel("Поставщик: " + p.SupplierName, 10, 75, 445, 22, p);
            Label lblUnit = CreateInfoLabel("Единица измерения: " + p.UnitName, 10, 119, 260, 22, p);
            Label lblStock = CreateInfoLabel("Количество на складе: " + p.QuantityInStock.ToString("N0"), 10, 140, 330, 22, p);

            infoBlock.Controls.Add(lblTitle);
            infoBlock.Controls.Add(lblDescription);
            infoBlock.Controls.Add(lblManufacturer);
            infoBlock.Controls.Add(lblSupplier);
            AddPriceLabels(infoBlock, card, p);
            infoBlock.Controls.Add(lblUnit);
            infoBlock.Controls.Add(lblStock);

            Panel discountBlock = new Panel();
            discountBlock.Location = new Point(746, 12);
            discountBlock.Size = new Size(135, 160);
            discountBlock.BorderStyle = BorderStyle.FixedSingle;
            discountBlock.BackColor = cardColor;
            discountBlock.Tag = p;

            Label lblDiscount = new Label();
            lblDiscount.Location = new Point(8, 45);
            lblDiscount.Size = new Size(118, 60);
            lblDiscount.Font = new Font("Times New Roman", 10F, FontStyle.Bold);
            lblDiscount.Text = "Действующая\nскидка\n" + p.CurrentDiscount.ToString("N0") + "%";
            lblDiscount.TextAlign = ContentAlignment.MiddleCenter;
            lblDiscount.Tag = p;
            discountBlock.Controls.Add(lblDiscount);

            card.Controls.Add(photoBlock);
            card.Controls.Add(infoBlock);
            card.Controls.Add(discountBlock);

            AddCardEvents(card, card);
            AddCardEvents(photoBlock, card);
            AddCardEvents(infoBlock, card);
            AddCardEvents(discountBlock, card);
            AddCardEvents(pic, card);
            AddCardEvents(photoText, card);
            AddCardEvents(lblTitle, card);
            AddCardEvents(lblDescription, card);
            AddCardEvents(lblSupplier, card);
            AddCardEvents(lblManufacturer, card);
            AddCardEvents(lblUnit, card);
            AddCardEvents(lblStock, card);
            AddCardEvents(lblDiscount, card);

            return card;
        }

        private Label CreateInfoLabel(string text, int x, int y, int width, int height, Product product)
        {
            Label label = new Label();
            label.Text = text;
            label.Location = new Point(x, y);
            label.Size = new Size(width, height);
            label.AutoEllipsis = true;
            label.Tag = product;
            return label;
        }

        private void AddPriceLabels(Panel infoBlock, Panel card, Product p)
        {
            if (p.CurrentDiscount > 0)
            {
                double finalPrice = p.Price * (1 - p.CurrentDiscount / 100.0);

                Label priceTitle = CreateInfoLabel("Цена:", 10, 97, 50, 22, p);

                Label oldPrice = new Label();
                oldPrice.Location = new Point(60, 97);
                oldPrice.Size = new Size(120, 22);
                oldPrice.Text = p.Price.ToString("N2") + " руб.";
                oldPrice.ForeColor = Color.Red;
                oldPrice.Font = new Font("Times New Roman", 11F, FontStyle.Strikeout);
                oldPrice.Tag = p;

                Label newPrice = new Label();
                newPrice.Location = new Point(185, 97);
                newPrice.Size = new Size(210, 22);
                newPrice.Text = finalPrice.ToString("N2") + " руб.";
                newPrice.ForeColor = Color.Black;
                newPrice.Font = new Font("Times New Roman", 11F, FontStyle.Bold);
                newPrice.Tag = p;

                infoBlock.Controls.Add(priceTitle);
                infoBlock.Controls.Add(oldPrice);
                infoBlock.Controls.Add(newPrice);

                AddCardEvents(priceTitle, card);
                AddCardEvents(oldPrice, card);
                AddCardEvents(newPrice, card);
            }
            else
            {
                Label price = CreateInfoLabel("", 10, 97, 250, 22, p);
                price.Text = "Цена: " + p.Price.ToString("N2") + " руб.";
                price.ForeColor = Color.Black;

                infoBlock.Controls.Add(price);
                AddCardEvents(price, card);
            }
        }

        private void AddCardEvents(Control control, Panel card)
        {
            control.Click += delegate
            {
                SelectCard(card);
            };

            control.DoubleClick += delegate
            {
                SelectCard(card);

                if (user.Role == UserRole.Admin)
                    OpenEditForm(card.Tag as Product);
            };
        }

        private Color GetCardColor(Product p)
        {
            if (p.QuantityInStock <= 0)
                return Color.LightBlue;

            if (p.CurrentDiscount > 15)
                return ColorTranslator.FromHtml("#2E8B57");

            return Color.White;
        }

        private Image LoadProductImage(string fileName)
        {
            string imagesFolder = Path.Combine(Application.StartupPath, "Images");
            string stubPath = Path.Combine(imagesFolder, "picture.png");

            // Если фото товара отсутствует или повреждено, показывается Images\picture.png.
            string imagePath = "";

            if (!string.IsNullOrWhiteSpace(fileName))
            {
                string productPath = Path.Combine(imagesFolder, fileName);

                if (File.Exists(productPath))
                    imagePath = productPath;
            }

            if (string.IsNullOrWhiteSpace(imagePath) && File.Exists(stubPath))
                imagePath = stubPath;

            if (string.IsNullOrWhiteSpace(imagePath))
                return null;

            Image image = TryLoadImageCopy(imagePath);

            if (image != null)
                return image;

            if (!string.Equals(imagePath, stubPath, StringComparison.OrdinalIgnoreCase) && File.Exists(stubPath))
                return TryLoadImageCopy(stubPath);

            return null;
        }

        private Image TryLoadImageCopy(string imagePath)
        {
            try
            {
                using (FileStream fs = new FileStream(imagePath, FileMode.Open, FileAccess.Read))
                using (Image temp = Image.FromStream(fs))
                {
                    return new Bitmap(temp);
                }
            }
            catch
            {
                return null;
            }
        }

        private void SelectCard(Panel selectedCard)
        {
            foreach (Control item in panelProducts.Controls)
            {
                Product product = item.Tag as Product;
                RestoreCardColor(item, GetCardColor(product));
            }

            RestoreCardColor(selectedCard, ColorTranslator.FromHtml("#00FA9A"));
            panelProducts.Tag = selectedCard.Tag;
        }

        private void RestoreCardColor(Control control, Color color)
        {
            control.BackColor = color;

            foreach (Control child in control.Controls)
            {
                if (child is PictureBox || child is Button)
                    continue;

                Label label = child as Label;
                if (label != null && label.BorderStyle == BorderStyle.FixedSingle)
                    child.BackColor = Color.White;
                else
                    RestoreCardColor(child, color);
            }
        }

        private Product SelectedProduct()
        {
            return panelProducts.Tag as Product;
        }

        private void OpenEditForm(Product product)
        {
            if (product == null)
                return;

            // Администратор не должен открыть несколько окон редактирования товара одновременно.
            if (isProductEditFormOpen)
            {
                MessageHelper.Warning(
                    "Окно редактирования товара уже открыто.\n\n" +
                    "Завершите добавление или редактирование текущего товара, затем откройте следующий.");
                return;
            }

            isProductEditFormOpen = true;

            try
            {
                ProductEditForm form = new ProductEditForm(product);

                if (form.ShowDialog() == DialogResult.OK)
                    LoadProducts();
            }
            finally
            {
                isProductEditFormOpen = false;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (isProductEditFormOpen)
            {
                MessageHelper.Warning(
                    "Окно редактирования товара уже открыто.\n\n" +
                    "Завершите добавление или редактирование текущего товара, затем откройте следующий.");
                return;
            }

            isProductEditFormOpen = true;

            try
            {
                ProductEditForm form = new ProductEditForm(null);

                if (form.ShowDialog() == DialogResult.OK)
                    LoadProducts();
            }
            finally
            {
                isProductEditFormOpen = false;
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            Product p = SelectedProduct();

            if (p == null)
            {
                MessageHelper.Warning(
                    "Товар не выбран.\n\n" +
                    "Сначала нажмите на карточку товара, затем повторите действие.");
                return;
            }

            OpenEditForm(p);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            Product p = SelectedProduct();

            if (p == null)
            {
                MessageHelper.Warning(
                    "Товар не выбран.\n\n" +
                    "Сначала нажмите на карточку товара, затем повторите действие.");
                return;
            }

            if (MessageHelper.Confirm(
                "Вы действительно хотите удалить выбранный товар?\n\n" +
                "Это действие нельзя отменить. Если товар используется в заказах, удаление будет запрещено."))
            {
                try
                {
                    db.DeleteProduct(p.ArticleNumber);
                    MessageHelper.Info("Товар успешно удален.");
                    LoadProducts();
                }
                catch (Exception ex)
                {
                    MessageHelper.Error(
                        "Не удалось удалить товар.\n\n" +
                        "Возможная причина: товар используется в заказах. Удалите связанные записи заказа или оставьте товар в базе.\n\n" +
                        "Техническая информация:\n" + ex.Message);
                }
            }
        }

        private void btnOrders_Click(object sender, EventArgs e)
        {
            OrdersForm form = new OrdersForm(user);
            form.ShowDialog();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
