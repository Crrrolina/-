﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace ToysStore
{
    public partial class OrdersForm : Form
    {
        private Db db = new Db();
        private CurrentUser user;
        private List<OrderView> orders = new List<OrderView>();

        public OrdersForm(CurrentUser currentUser)
        {
            user = currentUser;
            InitializeComponent();
            LoadFormIcon();

            bool isAdmin = user.Role == UserRole.Admin;

            // Управление заказами доступно только администратору.
            btnAdd.Visible = isAdmin;
            btnEdit.Visible = isAdmin;
            btnDelete.Visible = isAdmin;

            LoadOrders();
        }

        private void LoadFormIcon()
        {
            string iconPath = Path.Combine(Application.StartupPath, "Images", "Icon.ico");

            if (!File.Exists(iconPath))
                return;

            try
            {
                Icon = new Icon(iconPath);
            }
            catch
            {
                Icon = null;
            }
        }
        private void LoadOrders()
        {
            try
            {
                orders = db.GetOrders();

                lblHeader.Text = "Заказы | " + orders.Count + " записей";

                panelOrders.Controls.Clear();
                panelOrders.Tag = null;

                foreach (OrderView order in orders)
                {
                    panelOrders.Controls.Add(CreateOrderCard(order));
                }
            }
            catch (Exception ex)
            {
                MessageHelper.Error(
                    "Не удалось загрузить список заказов.\n\n" +
                    "Проверьте подключение к базе данных и наличие таблиц Orders, OrderItems, Products, Persons, PickupPoints.\n\n" +
                    "Техническая информация:\n" + ex.Message);
            }
        }

        private Panel CreateOrderCard(OrderView order)
        {
            // Карточка повторяет макет задания; дополнительные поля оставлены в левом блоке.
            Panel outerCard = new Panel();
            outerCard.Width = 900;
            outerCard.Height = 155;
            outerCard.Margin = new Padding(5, 5, 5, 12);
            outerCard.BorderStyle = BorderStyle.FixedSingle;
            outerCard.BackColor = Color.White;
            outerCard.Tag = order;

            Panel leftBlock = new Panel();
            leftBlock.Location = new Point(25, 17);
            leftBlock.Size = new Size(675, 115);
            leftBlock.BorderStyle = BorderStyle.FixedSingle;
            leftBlock.BackColor = Color.White;
            leftBlock.Tag = order;

            Panel rightBlock = new Panel();
            rightBlock.Location = new Point(725, 17);
            rightBlock.Size = new Size(145, 115);
            rightBlock.BorderStyle = BorderStyle.FixedSingle;
            rightBlock.BackColor = Color.White;
            rightBlock.Tag = order;

            Label lblLeft = new Label();
            lblLeft.Location = new Point(10, 8);
            lblLeft.Size = new Size(650, 102);
            lblLeft.Font = new Font("Times New Roman", 11F, FontStyle.Bold);
            lblLeft.Text =
                "Артикул заказа: " + order.OrderNumber + "\n" +
                "Статус заказа: " + order.StatusName + "\n" +
                "Адрес пункта выдачи: " + order.PickupAddress + "\n" +
                "Дата заказа: " + order.OrderDate + "\n" +
                "Пользователь: " + order.PersonName + " | Код: " + order.PickupCode + " | Сумма: " + order.Total.ToString("N2") + " руб.";
            lblLeft.AutoEllipsis = true;
            lblLeft.Tag = order;

            Label lblRightTitle = new Label();
            lblRightTitle.Location = new Point(8, 10);
            lblRightTitle.Size = new Size(125, 25);
            lblRightTitle.Font = new Font("Times New Roman", 11F, FontStyle.Bold);
            lblRightTitle.Text = "Дата доставки";
            lblRightTitle.TextAlign = ContentAlignment.MiddleCenter;
            lblRightTitle.Tag = order;

            Label lblDeliveryDate = new Label();
            lblDeliveryDate.Location = new Point(8, 42);
            lblDeliveryDate.Size = new Size(125, 48);
            lblDeliveryDate.Font = new Font("Times New Roman", 11F, FontStyle.Regular);
            lblDeliveryDate.Text = order.DeliveryDate;
            lblDeliveryDate.TextAlign = ContentAlignment.MiddleCenter;
            lblDeliveryDate.Tag = order;

            leftBlock.Controls.Add(lblLeft);
            rightBlock.Controls.Add(lblRightTitle);
            rightBlock.Controls.Add(lblDeliveryDate);

            outerCard.Controls.Add(leftBlock);
            outerCard.Controls.Add(rightBlock);

            AddCardEvents(outerCard, outerCard);
            AddCardEvents(leftBlock, outerCard);
            AddCardEvents(rightBlock, outerCard);
            AddCardEvents(lblLeft, outerCard);
            AddCardEvents(lblRightTitle, outerCard);
            AddCardEvents(lblDeliveryDate, outerCard);

            return outerCard;
        }

        private void AddCardEvents(Control control, Panel card)
        {
            control.Click += delegate
            {
                SelectCard(card);
            };

            control.DoubleClick += delegate
            {
                SelectCard(card);

                if (user.Role == UserRole.Admin)
                    OpenEditForm(card.Tag as OrderView);
            };
        }

        private void SelectCard(Panel selected)
        {
            foreach (Control control in panelOrders.Controls)
            {
                control.BackColor = Color.White;

                foreach (Control child in control.Controls)
                {
                    child.BackColor = Color.White;
                    foreach (Control innerChild in child.Controls)
                    {
                        innerChild.BackColor = Color.White;
                    }
                }
            }

            selected.BackColor = ColorTranslator.FromHtml("#00FA9A");
            panelOrders.Tag = selected.Tag;
        }

        private OrderView GetSelectedOrder()
        {
            return panelOrders.Tag as OrderView;
        }

        private void OpenEditForm(OrderView order)
        {
            if (order == null)
                return;

            OrderEditForm form = new OrderEditForm(order);

            if (form.ShowDialog() == DialogResult.OK)
                LoadOrders();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            OrderEditForm form = new OrderEditForm(null);

            if (form.ShowDialog() == DialogResult.OK)
                LoadOrders();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            OrderView order = GetSelectedOrder();

            if (order == null)
            {
                MessageHelper.Warning(
                    "Заказ не выбран.\n\n" +
                    "Сначала нажмите на карточку заказа, затем повторите действие.");
                return;
            }

            OpenEditForm(order);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            OrderView order = GetSelectedOrder();

            if (order == null)
            {
                MessageHelper.Warning(
                    "Заказ не выбран.\n\n" +
                    "Сначала нажмите на карточку заказа, затем повторите действие.");
                return;
            }

            if (MessageHelper.Confirm(
                "Вы действительно хотите удалить заказ №" + order.OrderNumber + "?\n\n" +
                "Будут удалены заказ и все товары из его состава. Это действие нельзя отменить."))
            {
                try
                {
                    db.DeleteOrder(order.OrderNumber);
                    MessageHelper.Info("Заказ успешно удален.");
                    LoadOrders();
                }
                catch (Exception ex)
                {
                    MessageHelper.Error(
                        "Не удалось удалить заказ.\n\n" +
                        "Проверьте подключение к базе данных и повторите попытку.\n\n" +
                        "Техническая информация:\n" + ex.Message);
                }
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadOrders();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

